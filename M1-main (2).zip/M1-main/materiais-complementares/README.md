# Materias Complementares

## Semana 1

### Programação

1. Introdução ao Github Markdown. Disponível em: [docs.github.com](https://docs.github.com/pt/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)
2. Tutorial Git e Github. Disponível em: [Youtube](https://www.youtube.com/watch?v=UBAX-13g8OM)
3. Instalação de Ferramentas (VSCode, Node, Github Desktop). Disponível em (apenas com email do Inteli): [Google Drive](https://drive.google.com/drive/folders/1v1jayjYxkW_3djlTPbPUfJ3g3hQ5d3sh)
4. Extensão Code Runner do VSCode. Disponível em: [Marketplace Visual Studio](https://marketplace.visualstudio.com/items?itemName=formulahendry.code-runner) 
